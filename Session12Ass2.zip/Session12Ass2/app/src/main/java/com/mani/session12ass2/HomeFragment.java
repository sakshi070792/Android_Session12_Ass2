package com.mani.session12ass2;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * Created by sakshi.banger on 13-10-2016.
 */
public class HomeFragment extends android.app.Fragment {
    SharedPreferences sharedPreferences;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.home_fragment,container,false);
        TextView tvnumber = (TextView) view.findViewById(R.id.tvnumber);
        sharedPreferences = getActivity().getSharedPreferences("prefName", Context.MODE_APPEND);
        String number = sharedPreferences.getString("number", null);
        tvnumber.setText(number);
        return view;
    }
}