package com.mani.session12ass2;

import android.app.Activity;
import android.content.Context;

import android.app.Activity;
        import android.app.Fragment;
        import android.app.FragmentManager;
        import android.app.FragmentTransaction;
        import android.content.Context;
        import android.content.SharedPreferences;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.EditText;
        import android.widget.TextView;

public class MainActivity extends Activity implements View.OnClickListener {
    TextView tvsubmit;
    EditText etnumber;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etnumber=(EditText) findViewById(R.id.etnumber);
        tvsubmit=(TextView)findViewById(R.id.tvsubmit);
        tvsubmit.setOnClickListener(this);
        sharedPreferences=getSharedPreferences("prefName", Context.MODE_APPEND);
        editor=sharedPreferences.edit();


    }
    public void onClick(View v) {
        Fragment fragmnent;
        String number=etnumber.getText().toString();
        editor.putString("number",number);
        editor.commit();
        fragmnent=new HomeFragment();
        FragmentManager fragmentManager=getFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.flcontainer, fragmnent);
        fragmentTransaction.commit();

    }
}

